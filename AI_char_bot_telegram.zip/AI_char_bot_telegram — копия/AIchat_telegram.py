import sys
import logging
import asyncio
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from transformers import GPT2LMHeadModel, GPT2Tokenizer
import torch
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QLabel,
    QFileDialog, QLineEdit
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
import nest_asyncio
from responses import responses

nest_asyncio.apply()

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

class GPT2Generator:
    def __init__(self, model_path):
        self.tokenizer = GPT2Tokenizer.from_pretrained(model_path)
        self.model = GPT2LMHeadModel.from_pretrained(model_path)

    def generate_text(self, input_text, temperature_value, length_value, num_results, no_repeat_ngram_size):
        input_ids = self.tokenizer.encode(input_text, return_tensors='pt')
        attention_mask = torch.ones(input_ids.shape, dtype=torch.long, device=input_ids.device)

        outputs = self.model.generate(
            input_ids=input_ids,
            attention_mask=attention_mask,
            max_length=length_value,
            num_return_sequences=num_results,
            no_repeat_ngram_size=no_repeat_ngram_size,
            repetition_penalty=1.5,
            temperature=temperature_value,
            do_sample=True
        )

        result_text = ""
        for i, output in enumerate(outputs):
            generated_text = self.tokenizer.decode(output, skip_special_tokens=True)
            if i == 0:
                generated_text = generated_text.replace(input_text, "")
            result_text += generated_text + "\n\n"

        return result_text

class TelegramBotThread(QThread):
    bot_started = pyqtSignal()

    def __init__(self, model_path, bot_token, temperature, parent=None):
        super().__init__(parent)
        self.model_path = model_path
        self.bot_token = bot_token
        self.temperature = temperature
        self.application = None
        self.gpt2_generator = GPT2Generator(model_path)

    async def start_bot(self):
        self.application = ApplicationBuilder().token(self.bot_token).build()

        async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
            await update.message.reply_text('Привет! Меня зовут AIBot.')

        async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
            user_message = update.message.text.lower()
            if user_message in responses:
                response = responses[user_message]
            else:
                length_value = 50
                num_results = 1
                no_repeat_ngram_size = 2

                try:
                    response = self.gpt2_generator.generate_text(
                        user_message, self.temperature, length_value, num_results, no_repeat_ngram_size
                    )
                except Exception as e:
                    response = f"Error: {str(e)}"
            
            chunk_size = 4096
            for i in range(0, len(response), chunk_size):
                await update.message.reply_text(response[i:i + chunk_size])

        self.application.add_handler(CommandHandler('start', start))
        self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

        self.bot_started.emit()
        await self.application.initialize()
        await self.application.start()
        await self.application.updater.start_polling()

        try:
            await asyncio.Future()
        except asyncio.CancelledError:
            pass

        await self.application.stop()

    def run(self):
        asyncio.run(self.start_bot())

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("AIBot")
        self.setGeometry(100, 100, 400, 200)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        self.layout = QVBoxLayout()
        self.central_widget.setLayout(self.layout)

        # Поле для ввода токена бота
        self.token_input = QLineEdit(self)
        self.token_input.setPlaceholderText("Введите токен бота")
        self.layout.addWidget(self.token_input)

        # Кнопка для выбора папки с моделью
        self.select_model_button = QPushButton("Выбрать папку с моделью", self)
        self.select_model_button.clicked.connect(self.select_model_folder)
        self.layout.addWidget(self.select_model_button)

        # Поле для отображения выбранного пути модели
        self.model_path_label = QLabel("Папка с моделью не выбрана", self)
        self.model_path_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.layout.addWidget(self.model_path_label)

        # Кнопка для запуска бота
        self.start_button = QPushButton("Запустить бота", self)
        self.start_button.setStyleSheet(
            "QPushButton { background-color: #000000; color: white; border-radius: 10px; padding: 5px; }"
            "QPushButton:hover { background-color: #7d7d7d; }"
        )
        self.start_button.clicked.connect(self.start_bot)
        self.layout.addWidget(self.start_button)

        # Статус
        self.status_label = QLabel()
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status_label.setStyleSheet(
            "QLabel { background-color: #4a4a4a; border-radius: 10px; padding: 10px; }"
        )
        self.layout.addWidget(self.status_label)

        self.bot_thread = None
        self.model_path = ""
        self.bot_token = ""

    def select_model_folder(self):
        model_path = QFileDialog.getExistingDirectory(self, "Выберите папку с моделью")
        if model_path:
            self.model_path = model_path
            self.model_path_label.setText(f"Папка с моделью: {model_path}")

    def start_bot(self):
        self.bot_token = self.token_input.text()
        if not self.bot_token or not self.model_path:
            self.status_label.setText("Введите токен и выберите папку с моделью!")
            return
        
        temperature_value = 0.3

        self.bot_thread = TelegramBotThread(self.model_path, self.bot_token, temperature_value)
        self.bot_thread.bot_started.connect(self.on_bot_started)
        self.bot_thread.start()
        self.status_label.setText("Бот запускается...")

    def on_bot_started(self):
        self.status_label.setText("Бот запущен.")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())

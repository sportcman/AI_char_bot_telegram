import sys
import logging
import asyncio
import os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from transformers import GPT2LMHeadModel, GPT2Tokenizer
import torch
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QLabel,
    QFileDialog, QLineEdit
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
import nest_asyncio
import pylint.lint
import pytest
from responses import responses  # Убедитесь, что responses содержит нужные ответы

nest_asyncio.apply()

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

# Класс генератора текста GPT-2
class GPT2Generator:
    def __init__(self, model_path):
        self.tokenizer = GPT2Tokenizer.from_pretrained(model_path)
        self.model = GPT2LMHeadModel.from_pretrained(model_path)

    def generate_text(self, input_text, temperature, max_length, num_results, no_repeat_ngram_size):
        try:
            input_ids = self.tokenizer.encode(input_text, return_tensors='pt')
            outputs = self.model.generate(
                input_ids=input_ids,
                max_length=max_length,
                num_return_sequences=num_results,
                no_repeat_ngram_size=no_repeat_ngram_size,
                temperature=temperature,
                do_sample=True
            )
            result_text = "\n\n".join(self.tokenizer.decode(output, skip_special_tokens=True) for output in outputs)
            return result_text
        except Exception as e:
            logging.error(f"Ошибка генерации текста: {e}")
            return "Ошибка генерации текста"

# Поток для Telegram-бота
class TelegramBotThread(QThread):
    bot_started = pyqtSignal()

    def __init__(self, model_path, bot_token, temperature, parent=None):
        super().__init__(parent)
        self.model_path = model_path
        self.bot_token = bot_token
        self.temperature = temperature
        self.application = None
        self.gpt2_generator = GPT2Generator(model_path)

    async def start_bot(self):
        # Настройка и запуск Telegram-бота
        self.application = ApplicationBuilder().token(self.bot_token).build()

        async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
            await update.message.reply_text("Привет! Отправьте текст для генерации ответа или файл Python для анализа.")

        async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
            user_message = update.message.text.lower()
            response = responses.get(user_message) or self.gpt2_generator.generate_text(
                user_message, self.temperature, max_length=50, num_results=1, no_repeat_ngram_size=2
            )
            await update.message.reply_text(response[:4096])

        async def handle_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
            document = update.message.document
            if document.file_name.endswith('.py'):
                file = await document.get_file()
                file_path = f"./{document.file_name}"
                await file.download(file_path)
                pylint_results = self.run_pylint(file_path)
                pytest_results = self.run_pytest(file_path)
                await update.message.reply_text(f"Pylint Results:\n{pylint_results}\n\nPytest Results:\n{pytest_results}")
                os.remove(file_path)
            else:
                await update.message.reply_text("Пожалуйста, отправьте файл с расширением .py")

        self.application.add_handler(CommandHandler("start", start))
        self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
        self.application.add_handler(MessageHandler(filters.Document.FileExtension("py"), handle_file))

        self.bot_started.emit()
        await self.application.initialize()
        await self.application.start()
        await self.application.updater.start_polling()
        try:
            await asyncio.Future()
        except asyncio.CancelledError:
            pass
        await self.application.stop()

    def run_pylint(self, file_path):
        pylint_opts = [file_path]
        try:
            pylint_output = pylint.lint.Run(pylint_opts, do_exit=False).linter.reporter.out.getvalue()
            return pylint_output or "Ошибок нет"
        except Exception as e:
            return f"Ошибка в pylint: {e}"

    def run_pytest(self, file_path):
        try:
            pytest_output = pytest.main([file_path])
            return str(pytest_output) or "Ошибок нет"
        except Exception as e:
            return f"Ошибка в pytest: {e}"

    def run(self):
        asyncio.run(self.start_bot())

# Основное окно приложения PyQt6
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AIBot")
        self.setGeometry(100, 100, 500, 300)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        self.layout = QVBoxLayout()
        self.central_widget.setLayout(self.layout)

        self.token_input = QLineEdit(self)
        self.token_input.setPlaceholderText("Введите токен бота")
        self.layout.addWidget(self.token_input)

        self.select_model_button = QPushButton("Выбрать папку с моделью", self)
        self.select_model_button.clicked.connect(self.select_model_folder)
        self.layout.addWidget(self.select_model_button)

        self.model_path_label = QLabel("Папка с моделью не выбрана", self)
        self.model_path_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.layout.addWidget(self.model_path_label)

        self.start_button = QPushButton("Запустить бота", self)
        self.start_button.clicked.connect(self.start_bot)
        self.layout.addWidget(self.start_button)

        self.status_label = QLabel("", self)
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.layout.addWidget(self.status_label)

        self.bot_thread = None
        self.model_path = ""
        self.bot_token = ""

    def select_model_folder(self):
        self.model_path = QFileDialog.getExistingDirectory(self, "Выберите папку с моделью")
        self.model_path_label.setText(f"Папка с моделью: {self.model_path}" if self.model_path else "Папка с моделью не выбрана")

    def start_bot(self):
        self.bot_token = self.token_input.text().strip()
        if not self.bot_token or not self.model_path:
            self.status_label.setText("Введите токен и выберите папку с моделью!")
            return

        self.bot_thread = TelegramBotThread(self.model_path, self.bot_token, temperature=0.7)
        self.bot_thread.bot_started.connect(lambda: self.status_label.setText("Бот запущен"))
        self.bot_thread.start()
        self.status_label.setText("Бот запускается...")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
